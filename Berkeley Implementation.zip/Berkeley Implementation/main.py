from functools import reduce
from dateutil import parser
import threading
import datetime
import socket
import time

#Armazenando o endereço do cliente e dados do clock
client_data = {}


#Função de thread aninhada usada para receber hora do relógio de um cliente conectado
def startReceivingClockTime(connector, address):

	while True:
		#Recebendo o clock time
		clock_time_string = connector.recv(1024).decode()
		clock_time = parser.parse(clock_time_string)
		clock_time_diff = datetime.datetime.now() - \
												clock_time

		client_data[address] = {
					"clock_time"	 : clock_time,
					"time_difference" : clock_time_diff,
					"connector"	 : connector
					}

		print("Dados do cliente atualizados: "+ str(address),
											end = "\n\n")
		time.sleep(5)


#Função de thread mestre usada para abrir o portal para aceitar clientes em determinada porta.
def startConnecting(master_server):
	
	#Buscar a hora do relógio dos clientes
	while True:
		#Aceitando um cliente
		master_slave_connector, addr = master_server.accept()
		slave_address = str(addr[0]) + ":" + str(addr[1])

		print(slave_address + " conectado com sucesso.")

		current_thread = threading.Thread(
						target = startReceivingClockTime,
						args = (master_slave_connector,
										slave_address, ))
		current_thread.start()


#Função de sub-rotina usada para buscar a diferença média de clock
def getAverageClockDiff():

	current_client_data = client_data.copy()

	time_difference_list = list(client['time_difference']
								for client_addr, client
									in client_data.items())
									

	sum_of_clock_difference = sum(time_difference_list, \
								datetime.timedelta(0, 0))

	average_clock_difference = sum_of_clock_difference \
										/ len(client_data)

	return average_clock_difference

#Função de thread de sincronização mestre usada para gerar ciclos de sincronização do relógio na rede 
def synchronizeAllClocks():

	while True:

		print("New synchronization cycle started.")
		print("Number of clients to be synchronized: " + \
									str(len(client_data)))

		if len(client_data) > 0:

			average_clock_difference = getAverageClockDiff()

			for client_addr, client in client_data.items():
				try:
					synchronized_time = \
						datetime.datetime.now() + \
									average_clock_difference

					client['connector'].send(str(
							synchronized_time).encode())

				except Exception as e:
					print("Algo deu errado ao sincronizar o tempo" + str(client_addr))

		else :
			print("Sem dados do cliente, sincronização impossibilitada.")

		print("\n\n")

		time.sleep(5)

#Função para iniciar o Clock Server
def initiateClockServer(port = 8080):

	master_server = socket.socket()
	master_server.setsockopt(socket.SOL_SOCKET,
								socket.SO_REUSEADDR, 1)

	print("Socket criado com sucesso.\n")
	
	master_server.bind(('', port))

	# Ouvindo as requests
	master_server.listen(10)
	print("Clock server iniciado.\n")

	#Começando conexões
	print("Iniciando as conexões.\n")
	master_thread = threading.Thread(
						target = startConnecting,
						args = (master_server, ))
	master_thread.start()

	#Iniciando sincronização
	print("Iniciando sincronização paralelamente.\n")
	sync_thread = threading.Thread(
						target = synchronizeAllClocks,
						args = ())
	sync_thread.start()



#Driver function
if __name__ == '__main__':

	#Disparando o Clock Server
	initiateClockServer(port = 8080)
